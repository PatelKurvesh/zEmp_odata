sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("zemp.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  